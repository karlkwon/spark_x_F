^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot3_manipulation_cartographer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.1.1 (2022-10-14)
------------------
* Support ROS2 Humble
* MoveIt environment configured
* use ros2_control framework instead of ROBOTIS custom library
* removed dependency to `turtlebot3_*`` and `open_manipulator` packages
* Contributors: Hye-Jong KIM, Darby Lim, Will Son
